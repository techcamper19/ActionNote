Subject: Welcome to ActionNote – turn meetings into actions

Hi {{first_name}},

Thank you for joining the ActionNote waitlist! 🎉 We’re building a tool that transforms your meeting transcripts into concise summaries and actionable task lists so you can focus on what matters.

Over the next few weeks we’ll be opening up early access. Stay tuned for your invite. In the meantime, feel free to reply to this email if you have any questions or suggestions—we’d love to hear from you.

Cheers,
The ActionNote Team
