Subject: Your ActionNote beta invite is here!

Hi {{first_name}},

We’re excited to welcome you to the ActionNote beta. Click the link below to create your account and start turning your meeting transcripts into clear summaries and actionable tasks:

[Activate your account]({{activation_link}})

As a beta user you’ll have unlimited access to all features. We’d love your feedback to help us shape the product. Let us know what works, what doesn’t, and what features you’d like to see next.

Thanks for being part of the journey!

— The ActionNote Team
