Subject: Unlock unlimited summaries – upgrade to Pro or Team

Hi {{first_name}},

We hope you’re enjoying ActionNote! You’ve reached the limit of your free plan. To continue generating summaries without interruption, consider upgrading:

* **Pro – $9/month:** unlimited summaries for individuals.
* **Team – $29/month:** collaborate with your team, assign tasks and manage shared projects.

Upgrading is quick—just click the button below to choose your plan:

[Upgrade now]({{upgrade_link}})

Thanks for using ActionNote!

— The ActionNote Team
