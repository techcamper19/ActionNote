**LinkedIn Ad Copy**

**Headline:** Stop taking notes, start taking action

**Body:** Meetings shouldn’t slow you down. ActionNote uses AI to transcribe your calls, summarise what was said and pull out the next steps. Share your notes to Notion, Slack or email with a single click. Sign up for free and get ahead of your to‑do list.

**Call‑to‑Action:** Start for free
