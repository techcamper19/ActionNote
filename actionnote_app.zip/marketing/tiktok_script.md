**TikTok Ad Script – 30 seconds**

*Visual: Person on a video call frantically scribbling notes, looking stressed.*

**Voiceover:** “Still wasting time taking meeting notes?”

*Cut to screen recording of ActionNote summarising a transcript and generating tasks.*

**Voiceover:** “Meet **ActionNote** – the AI that turns messy transcripts into clear summaries and action items. Upload or paste your meeting, and let ActionNote do the heavy lifting. Export to Notion, Slack or email in one click.”

*On‑screen text:* “Turn meetings into actions, instantly.”

**Voiceover:** “Join our beta today – link in bio.”

*End with logo and call‑to‑action.*
